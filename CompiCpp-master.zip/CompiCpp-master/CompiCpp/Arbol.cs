﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CompiCpp
{
    public enum TipoNodoArbol
    {
        Expresion, Sentencia, Condicional
    }
    public enum TipoSentencia
    {
        IF,
        FOR,
        ASIGNACION,
        LEER,
        ESCRIBIR,
        NADA
    }
    public enum tipoExpresion
    {
        Operador,
        Constante,
        Identificador,
        NADA
    }
    public enum tipoOperador
    {
        Suma,
        Resta,
        Multiplicacion,
        Division,
        NADA
    }
    public enum OperacionCondicional
    {
        IgualIgual,
        MenorQue,
        MayorQue,
        MenorIgualQue,
        MayorIgualQue,
        Diferente,
        NADA
    }

    /*
     for(int s = 0; s<3;s++){
    
    }
     
     */
    public class NodoArbol
    {                                      //    IF             EXP             ASIG       for
        public NodoArbol hijoIzquierdo;  //  condicional      operando izq    arbol exp   sentencias
        public NodoArbol hijoDerecho;     // if false          operando der                condicional
        public NodoArbol hijoCentro;      // if true 
        public NodoArbol hermano;     // apunta a la siguiente instruccion (arbol)

        public TipoNodoArbol soyDeTipoNodo;
        public TipoSentencia soySentenciaDeTipo;

        public tipoExpresion SoyDeTipoExpresion;
        public tipoOperador soyDeTipoOperacion;
        // semantico ... gramatica con atributo
        public OperacionCondicional soyOperacionCondicionaDeTipo;

        public string lexema;

        //reglas semanticas // atributos
        //comprobacion de tipos y generacion de codigo intermedio
        public TipoDato SoyDeTipoDato;
        public TipoDato tipoValorNodoHijoIzquierdo; // valores sintetizados
        public TipoDato tipoValorNodoHijoDerecho;   // valores sintetizados

        public string memoriaAsignada; // conocer la memoria asignada
        public string valor;   //para hacer calculos codigo intermedio
        public string pCode;  // generar el codigo intermedio
        public string pCode1;  // generar el codigo intermedio
        public string pCode2;  // generar el codigo intermedio
        public string pCode3;  // generar el codigo intermedio
        public int linea;
    }
    public class Arbol
    {
        NodoArbol SigArbol = new NodoArbol();
        NodoArbol nodoraiz = new NodoArbol();
        public NodoClase nombreClaseActiva;
        public string nombreMetodoActivo;
        NodoArbol t = new NodoArbol();
        public int puntero;
        public List<NodoLexema> miListaTokenTemporal;

        public Arbol(List<NodoLexema> miListaTokenLexico)
        {
            puntero = 0;
            miListaTokenTemporal = miListaTokenLexico;
       
        }

        public NodoArbol CrearArbolSintacticoAbstracto()
        {
            
            nodoraiz = ObtenerSiguienteArbol();
            puntero++;
            if (nodoraiz != null) 
            {
                if (Lexico.Longitud > puntero)
                {
                   
                        nodoraiz.hermano = NodoHermano();
                    
   
                }
            }
            else
            {

                CrearArbolSintacticoAbstracto();
            }

       
            return nodoraiz;
        }


        private NodoArbol NodoHermano()
        {
            //NodoArbol t = ObtenerSiguienteArbol();
            //puntero++;
            //if (miListaTokenTemporal[puntero].Lexema != "$")
            //{
            //    t.hermano = NodoHermano();
            //}
            //return t;

            NodoArbol t;
        
            do 
            {
                t = ObtenerSiguienteArbol();
                puntero++;
                if(t==null && miListaTokenTemporal.Count == puntero)
                {
                    return t;
                
                }
               
            } while (t==null);

            if (miListaTokenTemporal.Count > puntero)
            {
                t.hermano = NodoHermano();
            }
                   //si lo dejo asi solo genera el arbol de la variable y del if por que no genera nodos nulos
                   //por que sale antes al cumplirse la condicional if y si todo lo encapsulo en otro metodo y uso recursion?
            //si el nodo t es nulo y resulta ser el final de la iteracion da error de referencian de objeto no establecida
            return t;
        }


        private NodoArbol ObtenerSiguienteArbol()
        {
             
                        switch (miListaTokenTemporal[puntero].Linea)
                    {
                        case -141: //if
                            SigArbol = CrearArbolIF();
                            //puntero++;
                            break;
                        case -1: //asignacion
                            SigArbol = CrearArbolAsignacion();
                            //puntero++;
                            break;
                        case -129: //for
                            SigArbol = CrearArbolFor();
                            //puntero++;
                            break;
                        case -73: // escritura
                            SigArbol = CrearNodoEscritura();
                            puntero++;
                            break;
                        case -74: // lectura
                            SigArbol = CrearNodoLectura();
                            //puntero++;
                            break;
                        default:
                            SigArbol = null;
                            //puntero++;
                            break;

                    }

                   
                
    

            return SigArbol;
        }
        #region Crear Arbol Condicional 
        public NodoArbol CrearArbolCondicional()
        {
            NodoArbol nodoRaiz = CrearArbolExpresion();
            if (miListaTokenTemporal[puntero].Linea == -11
                || miListaTokenTemporal[puntero].Linea == -16
                || miListaTokenTemporal[puntero].Linea == -15
                || miListaTokenTemporal[puntero].Linea == -13
                || miListaTokenTemporal[puntero].Linea == -14)
            {
                NodoArbol nodoTemp = NuevoNodoCondicional();

                switch (miListaTokenTemporal[puntero].Linea)
                {
                    case -11:
                        nodoTemp.soyOperacionCondicionaDeTipo = OperacionCondicional.IgualIgual;
                        break;
                    case -16:
                        nodoTemp.soyOperacionCondicionaDeTipo = OperacionCondicional.MenorIgualQue;
                        break;
                    case -15:
                        nodoTemp.soyOperacionCondicionaDeTipo = OperacionCondicional.MayorIgualQue;
                        break;
                    case -13:
                        nodoTemp.soyOperacionCondicionaDeTipo = OperacionCondicional.MayorQue;
                        break;
                    case -14:
                        nodoTemp.soyOperacionCondicionaDeTipo = OperacionCondicional.MenorQue;
                        break;
                    default:
                        break;
                }
                nodoTemp.hijoIzquierdo = nodoRaiz;
                nodoRaiz = nodoTemp;
                puntero++;
                nodoRaiz.hijoDerecho = CrearArbolExpresion();
            }

            return nodoRaiz;
        }
        #endregion       

        #region Crear ARBOL Expresion
        public NodoArbol CrearArbolExpresion()
        {
            NodoArbol nodoRaiz = Termino();
            while (miListaTokenTemporal[puntero].Linea==-4||miListaTokenTemporal[puntero].Linea==-5)
            {
                NodoArbol nodoTemp = NuevoNodoExpresion(tipoExpresion.Operador);
                nodoTemp.hijoIzquierdo = nodoRaiz;
                nodoTemp.soyDeTipoOperacion =
                    miListaTokenTemporal[puntero].Linea==-4
                    ? tipoOperador.Suma
                    : tipoOperador.Resta;
                if (miListaTokenTemporal[puntero].Linea==-4)
                {
                    nodoTemp.pCode = "adi;";
                }
                else
                {
                    nodoTemp.pCode = "sbi;";
                }
                nodoTemp.lexema = miListaTokenTemporal[puntero].Descripcion;
                nodoRaiz = nodoTemp;
                puntero++;
                nodoRaiz.hijoDerecho = Termino();
            }

            return nodoRaiz;
        }

        private NodoArbol Termino()
        {
            NodoArbol t = Factor();
            while (miListaTokenTemporal[puntero].Linea==-6|| miListaTokenTemporal[puntero].Linea==-7)
            {
                NodoArbol p = NuevoNodoExpresion(tipoExpresion.Operador);
                p.hijoIzquierdo = t;
                p.soyDeTipoOperacion = miListaTokenTemporal[puntero].Linea==-6
                    ? tipoOperador.Multiplicacion
                    : tipoOperador.Division;
                if (miListaTokenTemporal[puntero].Linea==-6)
                {
                    t.pCode = "mpi;";
                }
                else
                {
                    t.pCode = "div;";
                }

                t.lexema = miListaTokenTemporal[puntero].Descripcion;
                t = p;
                puntero++;
                t.hijoDerecho = Factor();
            }
            return t;
        }

        public NodoArbol Factor()
        {
            NodoArbol t = new NodoArbol();

            if (miListaTokenTemporal[puntero].Linea == -2) //ENTERO
            {
                
                t = NuevoNodoExpresion(tipoExpresion.Constante);
                t.pCode = " ldc " + miListaTokenTemporal[puntero].Linea + ";";
               t.SoyDeTipoDato = TipoDato.Int;
                t.lexema = miListaTokenTemporal[puntero].Descripcion;
               
            }
            if (miListaTokenTemporal[puntero].Linea == -3)  //decimal
            {
                t = NuevoNodoExpresion(tipoExpresion.Constante);
                t.pCode = " ldc " + miListaTokenTemporal[puntero].Descripcion + ";";
                t.lexema = miListaTokenTemporal[puntero].Descripcion;
               t.SoyDeTipoDato = TipoDato.Double;
                puntero++;
            }

            else if (miListaTokenTemporal[puntero].Linea == -1) // identificador
            {
                t = NuevoNodoExpresion(tipoExpresion.Identificador);
                t.lexema = miListaTokenTemporal[puntero].Descripcion;

                t.pCode = " lod " + miListaTokenTemporal[puntero].Descripcion + ";"; // gramatica con atributos
              //  t.SoyDeTipoDato =
                // TablaSimbolos.ObtenerTipoDato(
                //  miListaTokenTemporal[puntero].TextoLexema,
                //   nombreClaseActiva, nombreMetodoActivo); // gramatica con atributos

                puntero++;
            }
            else if (miListaTokenTemporal[puntero].Linea==-38)
            {
                puntero++;
                t = CrearArbolExpresion();
                puntero++;
            }
            return t;
        }

        #endregion      
        #region Crear ARBOL Asignacion
        public NodoArbol CrearArbolAsignacion()
        {
            var sentenciaAsignacion = NuevoNodoSentencia(TipoSentencia.ASIGNACION);
            sentenciaAsignacion.lexema = miListaTokenTemporal[puntero].Descripcion;
            sentenciaAsignacion.pCode = "lda " + miListaTokenTemporal[puntero].Descripcion + ";";
            sentenciaAsignacion.pCode1 = "sto;";
            puntero += 2;
            //sentenciaAsignacion.SoyDeTipoDato = TablaSimbolos.ObtenerTipoDato(sentenciaAsignacion.lexema, nombreClaseActiva, nombreMetodoActivo);
            sentenciaAsignacion.hijoIzquierdo = CrearArbolExpresion();

            return sentenciaAsignacion;

        }


        #endregion       
        #region Crear Arbol If
        public NodoArbol CrearArbolIF()
        {
            int a;
            var nodoArbolIF = NuevoNodoSentencia(TipoSentencia.IF);
            puntero += 2;
           
            nodoArbolIF.hijoIzquierdo = CrearArbolCondicional();
            puntero ++;

            //error cuando no hay comandos cuando la condicional es verdadera
            // validar que exista codigo en el TRUE
            nodoArbolIF.hijoCentro = ObtenerSiguienteArbol();
            if (miListaTokenTemporal[puntero].Linea != -43)
            {
                puntero ++;

            }
            //codigo cuando sea falso


            if (miListaTokenTemporal[puntero].Linea==-101)  // cambiar por el numero de token
            {
                puntero++;
                if (miListaTokenTemporal[puntero].Linea==-141) // cambiar por el numero de token
                {
                    CrearArbolIF();
                }
                else
                {
                    puntero++;
                    nodoArbolIF.hijoDerecho = NodoHermano();
                }
            }

            return nodoArbolIF;
        }


        #endregion
   
        #region Crear Arbol For

        private NodoArbol CrearArbolFor()
        {
            var nodoFor = NuevoNodoSentencia(TipoSentencia.FOR);

            nodoFor.hijoIzquierdo = CrearArbolAsignacion();

            nodoFor.hijoCentro = ObtenerSiguienteArbol();

            nodoFor.hijoDerecho = CrearArbolCondicional();
            
            return nodoFor;
        }

        #endregion
        #region Crear Arbol de Escritura
        private NodoArbol CrearNodoEscritura()
        {
            throw new NotImplementedException();
        }
        #endregion
        #region Crear Arbol Lectura
        private NodoArbol CrearNodoLectura()
        {
            throw new NotImplementedException();
        }

        #endregion

        #region Crear diferentes tipos de NodoArbol
        public NodoArbol NuevoNodoExpresion(tipoExpresion tipoExpresion)
        {
            NodoArbol nodo = new NodoArbol();

            nodo.soyDeTipoNodo = TipoNodoArbol.Expresion;

            nodo.SoyDeTipoExpresion = tipoExpresion;
            nodo.soyDeTipoOperacion = tipoOperador.NADA;
            nodo.SoyDeTipoDato = TipoDato.Nada;

            nodo.soySentenciaDeTipo = TipoSentencia.NADA;
            nodo.soyOperacionCondicionaDeTipo = OperacionCondicional.NADA;
            nodo.tipoValorNodoHijoDerecho = TipoDato.Nada;
            nodo.soyOperacionCondicionaDeTipo = OperacionCondicional.NADA;
            nodo.tipoValorNodoHijoIzquierdo = TipoDato.Nada;
            return nodo;
        }
        public NodoArbol NuevoNodoSentencia(TipoSentencia tipoSentencia)
        {
            NodoArbol nodo = new NodoArbol();
            nodo.soyDeTipoNodo = TipoNodoArbol.Sentencia;
            nodo.soySentenciaDeTipo = tipoSentencia;

            nodo.SoyDeTipoExpresion = tipoExpresion.NADA;
            nodo.soyDeTipoOperacion = tipoOperador.NADA;
            nodo.SoyDeTipoDato = TipoDato.Nada;


            nodo.soyOperacionCondicionaDeTipo = OperacionCondicional.NADA;
            nodo.tipoValorNodoHijoDerecho = TipoDato.Nada;
            nodo.soyOperacionCondicionaDeTipo = OperacionCondicional.NADA;
            nodo.tipoValorNodoHijoIzquierdo = TipoDato.Nada;
            return nodo;

        }
        public NodoArbol NuevoNodoCondicional()
        {
            NodoArbol nodo = new NodoArbol();
            nodo.soyDeTipoNodo = TipoNodoArbol.Condicional;

            nodo.SoyDeTipoExpresion = tipoExpresion.NADA;
            nodo.soyDeTipoOperacion = tipoOperador.NADA;
            nodo.SoyDeTipoDato = TipoDato.Nada;

            nodo.soySentenciaDeTipo = TipoSentencia.NADA;
            nodo.soyOperacionCondicionaDeTipo = OperacionCondicional.NADA;
            nodo.soyOperacionCondicionaDeTipo = OperacionCondicional.NADA;
            nodo.tipoValorNodoHijoDerecho = TipoDato.Nada;
            nodo.tipoValorNodoHijoIzquierdo = TipoDato.Nada;
            return nodo;

        }

        #endregion


    }
}
