﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CompiCpp
{
    public class GeneradorCodigoIntermedio
    {
        private StreamWriter sw;

        public GeneradorCodigoIntermedio()
        {
            sw = new StreamWriter("C:\\Users\\julio\\Documents\\PCODE.txt");

            sw.Close();
        }

        public void Ejecutar(NodoArbol miArbol)
        {
            ObtenerSiguienteCodigoIntermedio(miArbol);
            if (miArbol.hermano != null)
            {
                Ejecutar(miArbol.hermano);
            }
        }

        private void ObtenerSiguienteCodigoIntermedio(NodoArbol miArbol)
        {
            if (miArbol.soyDeTipoNodo == TipoNodoArbol.Sentencia
                && miArbol.soySentenciaDeTipo == TipoSentencia.ASIGNACION)
            {
                GenerarCodigoIntermedioAsignacion(miArbol);
            }
            else if (miArbol.soyDeTipoNodo == TipoNodoArbol.Sentencia &&
                miArbol.soySentenciaDeTipo == TipoSentencia.FOR)
            {
                GenerarCodigoIntermedioFor(miArbol);
            }
            //else if (miArbol.soyDeTipoNodo == TipoNodoArbol.Sentencia
            //    && miArbol.soySentenciaDeTipo == TipoSentencia.IF)
            //{
            //    GenerarCodigoIntermedioIF(miArbol);
            //}
        }

        public void GenerarCodigoIntermedioExpresion(NodoArbol miArbol)
        {
            if (miArbol.hijoIzquierdo != null) // tiene izquierda?
                GenerarCodigoIntermedioExpresion(miArbol.hijoIzquierdo);

            if (miArbol.hijoDerecho != null)  // tiene derecha?
                GenerarCodigoIntermedioExpresion(miArbol.hijoDerecho);

            // imprime            
            sw = File.AppendText("C:\\Users\\julio\\Documents\\PCODE.txt");
            sw.WriteLine(miArbol.pCode);
            sw.Close();



        }

        public void GenerarCodigoIntermedioAsignacion(NodoArbol miArbol)
        {
            sw = File.AppendText("C:\\Users\\julio\\Documents\\PCODE.txt");
            sw.WriteLine(miArbol.pCode);  // lda + lexema
            sw.Close();

            GenerarCodigoIntermedioExpresion(miArbol.hijoIzquierdo); // codep para expresion

            sw = File.AppendText("C:\\Users\\julio\\Documents\\PCODE.txt");
            sw.WriteLine(miArbol.pCode1); //sto
            sw.Close();

        }

        public void GenerarCodigoIntermedioIF(NodoArbol miArbol)
        {
            GenerarCodigoIntermedioCondicional(miArbol.hijoIzquierdo);
            sw = File.AppendText("C:\\Users\\julio\\Documents\\PCODE.txt");
            sw.WriteLine(miArbol.pCode); //sto
            sw.Close();
            ObtenerSiguienteCodigoIntermedio(miArbol.hijoCentro);
            sw = File.AppendText("C:\\Users\\julio\\Documents\\PCODE.txt");
            sw.WriteLine(miArbol.pCode2); //sto
            sw.Close();
            sw = File.AppendText("C:\\Users\\julio\\Documents\\PCODE.txt");
            sw.WriteLine(miArbol.pCode1); //sto
            sw.Close();
            ObtenerSiguienteCodigoIntermedio(miArbol.hijoDerecho);
            sw = File.AppendText("C:\\Users\\julio\\Documents\\PCODE.txt");
            sw.WriteLine(miArbol.pCode3); //sto
            sw.Close();
        }

        public void GenerarCodigoIntermedioCondicional(NodoArbol miArbol)
        {
            GenerarCodigoIntermedioExpresion(miArbol.hijoIzquierdo);
            GenerarCodigoIntermedioExpresion(miArbol.hijoDerecho);

            sw = File.AppendText("C:\\Users\\julio\\Documents\\PCODE.txt");
            sw.WriteLine(miArbol.pCode);
            sw.Close();

        }

        public void GenerarCodigoIntermedioWrite(NodoArbol miArbol)
        {

        }

        public void GenerarCodigoIntermedioRead(NodoArbol miArbol)
        {

        }

        public void GenerarCodigoIntermedioFor(NodoArbol miArbol)
        {

        }

    }
}
