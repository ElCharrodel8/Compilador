﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CompiCpp
{
    public enum TipoNodoArbol
    {
        Expresion, Sentencia, Condicional
    }
    public enum TipoSentencia
    {
        IF,
        FOR,
        ASIGNACION,
        LEER,
        ESCRIBIR,
        NADA
    }
    public enum tipoExpresion
    {
        Operador,
        Constante,
        Identificador,
        Cadena,
        NADA
    }
    //public enum tipoOperador
    //{
    //    Suma,
    //    Resta,
    //    Multiplicacion,
    //    Division,
    //    NADA
    //}
    public enum OperacionCondicional
    {
        IgualIgual,
        MenorQue,
        MayorQue,
        MenorIgualQue,
        MayorIgualQue,
        Diferente,
        NADA
    }

    /*
     for(int s = 0; s<3;s++){
    
    }
     
     */
    public class NodoArbol
    {                                      //    IF             EXP             ASIG       for
        public NodoArbol hijoIzquierdo;  //  condicional      operando izq    arbol exp   sentencias
        public NodoArbol hijoDerecho;     // if false          operando der                condicional
        public NodoArbol hijoCentro;      // if true 
        public NodoArbol hermano;     // apunta a la siguiente instruccion (arbol)

        public TipoNodoArbol soyDeTipoNodo;
        public TipoSentencia soySentenciaDeTipo;

        public tipoExpresion SoyDeTipoExpresion;
        public string soyDeTipoOperacion;
        // semantico ... gramatica con atributo
        public OperacionCondicional soyOperacionCondicionaDeTipo;

        public string lexema;

        //reglas semanticas // atributos
        //comprobacion de tipos y generacion de codigo intermedio
        public string SoyDeTipoDato;
        public string tipoValorNodoHijoIzquierdo; // valores sintetizados
        public string tipoValorNodoHijoDerecho;   // valores sintetizados

        public string memoriaAsignada; // conocer la memoria asignada
        public string valor;   //para hacer calculos codigo intermedio
        public string pCode;  // generar el codigo intermedio
        public string pCode1;  // generar el codigo intermedio
        public string pCode2;  // generar el codigo intermedio
        public string pCode3;  // generar el codigo intermedio
        public int linea;
    }
    public class Arbol
    {
        NodoArbol SigArbol = new NodoArbol();
        NodoArbol nodoraiz = new NodoArbol();
        public NodoClase nombreClaseActiva;
        public string nombreMetodoActivo;
        NodoArbol t = new NodoArbol();
        public int puntero;
        public List<NodoLexema> miListaTokenTemporal;
        public NodoClase claseActual;
        public string metodoActual;
        public Arbol(List<NodoLexema> miListaTokenLexico,NodoClase ClaseActual, string MetodoActual)
        {

            puntero = 0;
            miListaTokenTemporal = miListaTokenLexico;
            claseActual = ClaseActual;
            metodoActual = MetodoActual;
       
        }

        public NodoArbol CrearArbolSintacticoAbstracto()
        {
            
            nodoraiz = ObtenerSiguienteArbol();
         
                puntero++;
            
            
            if (nodoraiz != null) 
            {
                if (miListaTokenTemporal.Count > puntero)
                {
                   
                        nodoraiz.hermano = NodoHermano();
                    
   
                }
            }
            else
            {

                CrearArbolSintacticoAbstracto();
            }

       
            return nodoraiz;
        }


        private NodoArbol NodoHermano()
        {
           

            NodoArbol t;
        
            do 
            {
                t = ObtenerSiguienteArbol();
                puntero++;
                if(t==null && miListaTokenTemporal.Count == puntero)
                {
                    return t;
                
                }
               
            } while (t==null);

            if (miListaTokenTemporal.Count > puntero)
            {
                t.hermano = NodoHermano();
            }

            return t;
        }


        private NodoArbol ObtenerSiguienteArbol()
        {
             
                        switch (miListaTokenTemporal[puntero].Linea)
                    {
                        case -141: //if
                            SigArbol = CrearArbolIF();
                            //puntero++;
                            break;
                        case -1: //asignacion
                            SigArbol = CrearArbolAsignacion();
                            //puntero++;
                            break;
                        case -129: //for
                            SigArbol = CrearArbolFor();
                            //puntero++;
                            break;
                        case -165: // escritura/lectura
                            SigArbol = CrearNodoEscrituraLectura();
                            puntero++;
                            break;
                        case -74: // lectura
                            SigArbol = CrearNodoLectura();
                            //puntero++;
                            break;
                        default:
                            SigArbol = null;
                            //puntero++;
                            break;

                    }

                   
                
    

            return SigArbol;
        }
        #region Crear Arbol Condicional 
        public NodoArbol CrearArbolCondicional()
        {
            NodoArbol nodoRaiz = CrearArbolExpresion();
            if (miListaTokenTemporal[puntero].Linea == -11
                || miListaTokenTemporal[puntero].Linea == -16
                || miListaTokenTemporal[puntero].Linea == -15
                || miListaTokenTemporal[puntero].Linea == -13
                || miListaTokenTemporal[puntero].Linea == -14)
            {
                NodoArbol nodoTemp = NuevoNodoCondicional();

                switch (miListaTokenTemporal[puntero].Linea)
                {
                    case -11:
                        nodoTemp.soyOperacionCondicionaDeTipo = OperacionCondicional.IgualIgual;
                        break;
                    case -16:
                        nodoTemp.soyOperacionCondicionaDeTipo = OperacionCondicional.MenorIgualQue;
                        break;
                    case -15:
                        nodoTemp.soyOperacionCondicionaDeTipo = OperacionCondicional.MayorIgualQue;
                        break;
                    case -13:
                        nodoTemp.soyOperacionCondicionaDeTipo = OperacionCondicional.MayorQue;
                        break;
                    case -14:
                        nodoTemp.soyOperacionCondicionaDeTipo = OperacionCondicional.MenorQue;
                        break;
                    default:
                        break;
                }
                nodoTemp.hijoIzquierdo = nodoRaiz;
                nodoRaiz = nodoTemp;
                puntero++;
                nodoRaiz.hijoDerecho = CrearArbolExpresion();
            }

            return nodoRaiz;
        }
        #endregion       

        #region Crear ARBOL Expresion
        public NodoArbol CrearArbolExpresion()
        {
            NodoArbol nodoRaiz = Termino();
            while (miListaTokenTemporal[puntero].Linea==-4||miListaTokenTemporal[puntero].Linea==-5|| miListaTokenTemporal[puntero].Linea == -9|| miListaTokenTemporal[puntero].Linea == -10)
            {
                NodoArbol nodoTemp = NuevoNodoExpresion(tipoExpresion.Operador);
                nodoTemp.hijoIzquierdo = nodoRaiz;
                nodoTemp.soyDeTipoOperacion =
                    miListaTokenTemporal[puntero].Linea==-4
                    ? "Suma"
                    : "Resta";
                if (miListaTokenTemporal[puntero].Linea==-4 || miListaTokenTemporal[puntero].Linea == -9)
                {
                    nodoTemp.pCode = "adi;";
                    nodoTemp.lexema = "+";
                }
                else
                {
                    nodoTemp.pCode = "sbi;";
                    nodoTemp.lexema = "-";
                }
                if (miListaTokenTemporal[puntero].Linea == -9 || miListaTokenTemporal[puntero].Linea == -10)
                {
                    nodoRaiz = nodoTemp;
                    puntero++;
                    nodoRaiz.hijoDerecho = UNO();
                }
                else
                {
                    nodoRaiz = nodoTemp;
                    puntero++;
                    nodoRaiz.hijoDerecho = Termino();
                }
                
            }

            return nodoRaiz;
        }

        private NodoArbol Termino()
        {
            NodoArbol t = Factor();
            while (miListaTokenTemporal[puntero].Linea==-6|| miListaTokenTemporal[puntero].Linea==-7)
            {
                NodoArbol p = NuevoNodoExpresion(tipoExpresion.Operador);
                p.hijoIzquierdo = t;
                p.soyDeTipoOperacion = miListaTokenTemporal[puntero].Linea==-6
                    ? "Multiplicacion"
                    : "Division";
                if (miListaTokenTemporal[puntero].Linea==-6)
                {
                    t.pCode = "mpi;";
                }
                else
                {
                    t.pCode = "div;";
                }

                t.lexema = miListaTokenTemporal[puntero].Descripcion;
                t = p;
                puntero++;
                t.hijoDerecho = Factor();
            }
            return t;
        }
        public NodoArbol UNO()
        {
            NodoArbol t = new NodoArbol();
            t = NuevoNodoExpresion(tipoExpresion.Constante);
            t.pCode = " ldc 1;";
            t.SoyDeTipoDato = "int";
            t.lexema = "1";
            puntero++;

            return t;
        }
        public NodoArbol Factor()
        {

            NodoArbol t = new NodoArbol();

            if (miListaTokenTemporal[puntero].Linea == -2) //ENTERO
            {
                
                t = NuevoNodoExpresion(tipoExpresion.Constante);
                t.pCode = " ldc " + miListaTokenTemporal[puntero].Descripcion + ";";
               t.SoyDeTipoDato = "int";
                t.lexema = miListaTokenTemporal[puntero].Descripcion;
                puntero++;
               
            }
            if (miListaTokenTemporal[puntero].Linea == -3)  //decimal
            {
                t = NuevoNodoExpresion(tipoExpresion.Constante);
                t.pCode = " ldc " + miListaTokenTemporal[puntero].Descripcion + ";";
                t.lexema = miListaTokenTemporal[puntero].Descripcion;
               t.SoyDeTipoDato = "double";
                puntero++;
            }

            else if (miListaTokenTemporal[puntero].Linea == -1) // identificador
            {
                t = NuevoNodoExpresion(tipoExpresion.Identificador);
                t.lexema = miListaTokenTemporal[puntero].Descripcion;

                t.pCode = " lod " + miListaTokenTemporal[puntero].Descripcion + ";"; // gramatica con atributos
                t.SoyDeTipoDato = TablaSimbolos.obtenerTipoVariable(miListaTokenTemporal[puntero].Descripcion, claseActual,metodoActual);

                puntero++;
            }
            else if (miListaTokenTemporal[puntero].Linea==-38)
            {
                puntero++;
                t = CrearArbolExpresion();
                puntero++;
            }
            else if (miListaTokenTemporal[puntero].Linea == -9 || miListaTokenTemporal[puntero].Linea == -10)
            {
                t = NuevoNodoExpresion(tipoExpresion.Identificador);
                t.lexema = miListaTokenTemporal[puntero-1].Descripcion;

                t.pCode = " lod " + miListaTokenTemporal[puntero-1].Descripcion + ";";
                t.SoyDeTipoDato = TablaSimbolos.obtenerTipoVariable(miListaTokenTemporal[puntero].Descripcion, claseActual, metodoActual);
            }
            else if (miListaTokenTemporal[puntero].Linea == -34) // Cadena
            {
                t = NuevoNodoExpresion(tipoExpresion.Cadena);
                t.lexema = miListaTokenTemporal[puntero].Descripcion;
                t.SoyDeTipoDato = "string";
                t.pCode = " lod " + miListaTokenTemporal[puntero].Descripcion + ";"; 

                puntero++;
            }
            return t;
        }

        #endregion      
        #region Crear ARBOL Asignacion
        public NodoArbol CrearArbolAsignacion()
        {
            //if para eliminar el tipo de una variable declarada para poder formar el arbol desde el ID
            if (miListaTokenTemporal[puntero].Linea== -156|| miListaTokenTemporal[puntero].Linea == -149 || miListaTokenTemporal[puntero].Linea == -124||
                 miListaTokenTemporal[puntero].Linea == -125 || miListaTokenTemporal[puntero].Linea == -108 || miListaTokenTemporal[puntero].Linea == -164)
            {
                puntero++;
            }
            var sentenciaAsignacion = NuevoNodoSentencia(TipoSentencia.ASIGNACION);
            sentenciaAsignacion.lexema = miListaTokenTemporal[puntero].Descripcion;
            sentenciaAsignacion.pCode = "lda " + miListaTokenTemporal[puntero].Descripcion + ";";
            sentenciaAsignacion.pCode1 = "sto;";
            if (miListaTokenTemporal[puntero+1].Linea==-9|| miListaTokenTemporal[puntero + 1].Linea == -10)
                puntero ++;
            else
      
            //sentenciaAsignacion.SoyDeTipoDato = TablaSimbolos.ObtenerTipoDato(sentenciaAsignacion.lexema, nombreClaseActiva, nombreMetodoActivo);
           sentenciaAsignacion.SoyDeTipoDato = TablaSimbolos.obtenerTipoVariable(miListaTokenTemporal[puntero].Descripcion, claseActual, metodoActual);
            puntero += 2;
            sentenciaAsignacion.hijoIzquierdo = CrearArbolExpresion();

            return sentenciaAsignacion;

        }


        #endregion
        #region Crear Arbol Lectura Escritura
        public NodoArbol CrearArbolEscritura()
        {
            //falta codigo p
            var sentenciaAsignacion = NuevoNodoSentencia(TipoSentencia.ESCRIBIR);
            sentenciaAsignacion.lexema = miListaTokenTemporal[puntero].Descripcion;
            sentenciaAsignacion.pCode = "lda " + miListaTokenTemporal[puntero].Descripcion + ";";
            sentenciaAsignacion.pCode1 = "sto;";
            puntero += 2;
            //sentenciaAsignacion.SoyDeTipoDato = TablaSimbolos.ObtenerTipoDato(sentenciaAsignacion.lexema, nombreClaseActiva, nombreMetodoActivo);

            sentenciaAsignacion.SoyDeTipoDato = TablaSimbolos.obtenerTipoVariable(miListaTokenTemporal[puntero].Descripcion, claseActual, metodoActual);
            sentenciaAsignacion.hijoIzquierdo = Factor();

            return sentenciaAsignacion;

        }
        #endregion
        #region Crear Arbol If
        public NodoArbol HermanoSentencia()
        {
            NodoArbol arbolSentencia;

            do
            {
                if (miListaTokenTemporal[puntero].Linea == -149) { puntero++; }
                arbolSentencia = ObtenerSiguienteArbol();
                puntero++;
            } while (t==null);
        
           

            if (miListaTokenTemporal.Count > puntero)
            {
                if (miListaTokenTemporal[puntero].Linea != -43 && miListaTokenTemporal[puntero].Linea != -101) {
                    arbolSentencia.hermano = HermanoSentencia();
                }
               
            }

            return arbolSentencia;
        }
        public NodoArbol CrearArbolIF()
        {
     
            var nodoArbolIF = NuevoNodoSentencia(TipoSentencia.IF);
            puntero += 2;
           
            nodoArbolIF.hijoIzquierdo = CrearArbolCondicional();
            puntero+=2;

            //error cuando no hay comandos cuando la condicional es verdadera
            // validar que exista codigo en el TRUE
            if (miListaTokenTemporal[puntero].Linea != -43)
            {


                if (miListaTokenTemporal[puntero].Linea == -149 || miListaTokenTemporal[puntero].Linea == -156 || miListaTokenTemporal[puntero].Linea == -164 || miListaTokenTemporal[puntero].Linea == -124)
                {//no genera todos los hermanos por que se necesita recursion
                 //podre hacer un metodo para realizar el ciclo de creacion de nodos hermanos?
                    puntero++;
                    nodoArbolIF.hijoCentro = HermanoSentencia();
                    if(puntero> miListaTokenTemporal.Count - 1)
                    {
                        puntero++;

                    }
      

                }
                else
                {
                    nodoArbolIF.hijoCentro = HermanoSentencia();
                    if (puntero > miListaTokenTemporal.Count - 1)
                    {
                        puntero++;

                    }
                }

            }


            //codigo cuando sea falso             nodoArbolIF.hijoCentro 

        
               if (miListaTokenTemporal[puntero].Linea == -101)  // cambiar por el numero de token
               {
                   puntero += 2;
                if (miListaTokenTemporal[puntero].Linea!= -43) 
                {
                    if (miListaTokenTemporal[puntero].Linea == -149 || miListaTokenTemporal[puntero].Linea == -156 || miListaTokenTemporal[puntero].Linea == -164 || miListaTokenTemporal[puntero].Linea == -124)
                    {//no genera todos los hermanos por que se necesita recursion
                        //podre hacer un metodo para realizar el ciclo de creacion de nodos hermanos?
                        puntero++;
                        nodoArbolIF.hijoDerecho = HermanoSentencia();
                        if (puntero > miListaTokenTemporal.Count - 1)
                        {
                            puntero++;

                        }

                    }
                    else
                    {
                        nodoArbolIF.hijoDerecho = HermanoSentencia();
                        if (puntero > miListaTokenTemporal.Count - 1)
                        {
                            puntero++;

                        }
                    }
                }

               } 
            
    

            return nodoArbolIF;
        }

      

        #endregion
   
        #region Crear Arbol For

        private NodoArbol CrearArbolFor()
        {
            var nodoFor = NuevoNodoSentencia(TipoSentencia.FOR);
            puntero += 2;
            nodoFor.hijoIzquierdo = CrearArbolAsignacion();
            //-------------------------------f
            puntero++;
            nodoFor.hijoDerecho = CrearArbolCondicional();
            //--------------------------------------
            puntero++;
            nodoFor.hijoCentro = HermanoSentencia();

            return nodoFor;
        }

        #endregion
        #region Crear Arbol de Escritura o Lectura
        private NodoArbol CrearNodoEscrituraLectura()
        {
            NodoArbol CrearNodoEscrituraLectura;
            if ((miListaTokenTemporal[puntero+3].Linea== -166))
            {
                 CrearNodoEscrituraLectura = NuevoNodoSentencia(TipoSentencia.LEER);
                puntero += 5;
                CrearNodoEscrituraLectura.hijoIzquierdo = CrearArbolEscritura();
            }
            else
            {
                 CrearNodoEscrituraLectura = NuevoNodoSentencia(TipoSentencia.ESCRIBIR);
                puntero += 3;
                
            }

            return CrearNodoEscrituraLectura;
        }
        #endregion
        #region Crear Arbol Lectura
        private NodoArbol CrearNodoLectura()
        {
            throw new NotImplementedException();
        }

        #endregion

        #region Crear diferentes tipos de NodoArbol
        public NodoArbol NuevoNodoExpresion(tipoExpresion tipoExpresion)
        {
            NodoArbol nodo = new NodoArbol();

            nodo.soyDeTipoNodo = TipoNodoArbol.Expresion;

            nodo.SoyDeTipoExpresion = tipoExpresion;
            nodo.soyDeTipoOperacion = "Nada";
            nodo.SoyDeTipoDato = "Nada";

            nodo.soySentenciaDeTipo = TipoSentencia.NADA;
            nodo.soyOperacionCondicionaDeTipo = OperacionCondicional.NADA;
            nodo.tipoValorNodoHijoDerecho = "Nada";
            nodo.soyOperacionCondicionaDeTipo = OperacionCondicional.NADA;
            nodo.tipoValorNodoHijoIzquierdo = "Nada";
            return nodo;
        }
        public NodoArbol NuevoNodoSentencia(TipoSentencia tipoSentencia)
        {
            NodoArbol nodo = new NodoArbol();
            nodo.soyDeTipoNodo = TipoNodoArbol.Sentencia;
            nodo.soySentenciaDeTipo = tipoSentencia;

            nodo.SoyDeTipoExpresion = tipoExpresion.NADA;
            nodo.soyDeTipoOperacion = "Nada";
            nodo.SoyDeTipoDato = "Nada";


            nodo.soyOperacionCondicionaDeTipo = OperacionCondicional.NADA;
            nodo.tipoValorNodoHijoDerecho = "Nada";
            nodo.soyOperacionCondicionaDeTipo = OperacionCondicional.NADA;
            nodo.tipoValorNodoHijoIzquierdo = "Nada";
            return nodo;

        }
        public NodoArbol NuevoNodoCondicional()
        {
            NodoArbol nodo = new NodoArbol();
            nodo.soyDeTipoNodo = TipoNodoArbol.Condicional;

            nodo.SoyDeTipoExpresion = tipoExpresion.NADA;
            nodo.soyDeTipoOperacion = "Nada";
            nodo.SoyDeTipoDato = "Nada";

            nodo.soySentenciaDeTipo = TipoSentencia.NADA;
            nodo.soyOperacionCondicionaDeTipo = OperacionCondicional.NADA;
            nodo.soyOperacionCondicionaDeTipo = OperacionCondicional.NADA;
            nodo.tipoValorNodoHijoDerecho = "Nada";
            nodo.tipoValorNodoHijoIzquierdo = "Nada";
            return nodo;

        }

        #endregion


    }
}
